﻿function scrollToBottom(ref) {
    ref.scrollTop = ref.scrollHeight;
}